# -*- coding: utf-8 -*-
"""
Gerador de Fichas de Drenagem (DS) - Interface Gráfica
---------------------------------------------------------
Baseado no script original de drenagem, com os seguintes ajustes:
  - Mapeamento das colunas da planilha de dados pelo NOME do cabeçalho
    (em vez de letra fixa), para funcionar mesmo se a ordem das colunas
    mudar entre exportações.
  - Coluna de SENTIDO corrigida (lida pelo nome "Sentido", não mais a
    coluna D, que na verdade é "Faixa").
  - KM inicial/final convertidos para o formato KKK+MMM (ex.: 002+370),
    aceitando tanto número decimal (2.37) quanto texto com vírgula
    ("2,37") como separador decimal de km.
  - Capitalização: qualquer campo que vier 100% em maiúsculas da planilha
    é convertido para "Primeira letra maiúscula, resto minúsculo"
    (ex.: "RURAL" -> "Rural"), EXCETO a Identificação e a sigla da
    rodovia, que permanecem como estão.
  - Gera 1 arquivo .xlsx + 1 arquivo .pdf por elemento de drenagem
    (mesmo padrão do script original).

Como usar:
    1. Instale o Python 3 e as dependências:
       pip install openpyxl pywin32
    2. Execute:  python gerador_fichas_drenagem.py
    (Precisa do Microsoft Excel instalado, pois usa o Excel via COM
    para inserir as fotos e exportar o PDF, exatamente como o script
    original.)
"""
import os
import re
import sys
import threading
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from datetime import datetime

from openpyxl import load_workbook

try:
    import win32com.client
    WIN32COM_OK = True
except ImportError:
    WIN32COM_OK = False


# ----------------------------------------------------------------------
# Cabeçalhos esperados na planilha de dados (nome -> uso)
# ----------------------------------------------------------------------
CAMPOS = {
    'data': 'Encontrado em',
    'rodovia': 'Rodovia',
    'sentido': 'Sentido',
    'local': 'Local',
    'tipo_drenagem': 'Tipo de Drenagem',
    'ambiente': 'Ambiente',
    'material': 'Material da Drenagem',
    'estado_conservacao': 'Estado Geral de Conservação',
    'diagnostico': 'Diagnostico',
    'comprimento': 'Comprimento',
    'altura': 'Altura/Espessura',
    'largura': 'Largura',
    'limpeza_ext': 'Limpeza - Extensão',
    'reparar_ext': 'Reparar - Extensão',
    'implantar_ext': 'Implantar - Extensão',
    'km_inicial': 'km',
    'km_final': 'km final',
    'latitude': 'Latitude',
    'longitude': 'Longitude',
    'lat_final': 'Coordenada Final - Lat',
    'lon_final': 'Coordenada Final - Long',
    'foto1': 'Foto_1',
    'foto2': 'Foto_2',
    'identificacao': 'Identificação',
}

# Mapeamento simples: campo (ver CAMPOS) -> célula de destino na ficha-modelo.
MAPEAMENTO_SIMPLES = {
    'comprimento': 'B7',
    'largura': 'B8',
    'altura': 'G8',
    'latitude': 'B9',
    'longitude': 'B10',
    'lat_final': 'G9',
    'lon_final': 'G10',
    'estado_conservacao': 'G11',
    'ambiente': 'G12',
    'material': 'B12',
    'limpeza_ext': 'E16',
    'reparar_ext': 'E15',
    'implantar_ext': 'E17',
    'identificacao': 'B6',
}

# Campos que NUNCA são convertidos para "Primeira letra maiúscula" (ficam
# exatamente como vieram da planilha).
CAMPOS_SEM_CAPITALIZACAO = {'identificacao', 'rodovia'}


def to_str(valor):
    return "" if valor is None else str(valor)


def escrever_celula(ws, referencia, valor):
    """Escreve o valor na célula. Se a célula fizer parte de uma área
    mesclada (e não for a célula "âncora", a de cima-esquerda), escreve na
    âncora em vez de travar com erro (MergedCell é somente leitura)."""
    cell = ws[referencia]
    from openpyxl.cell.cell import MergedCell
    if isinstance(cell, MergedCell):
        for mc in ws.merged_cells.ranges:
            if referencia in mc:
                ws.cell(row=mc.min_row, column=mc.min_col).value = valor
                return
        return  # não deveria acontecer, mas evita travar
    cell.value = valor


def capitalizar_se_todo_maiusculo(valor):
    """Se o texto vier 100% em maiúsculas, devolve com só a primeira letra
    maiúscula e o resto minúsculo. Caso contrário, devolve sem alterar."""
    if not isinstance(valor, str):
        return valor
    texto = valor.strip()
    if not texto:
        return valor
    letras = [ch for ch in texto if ch.isalpha()]
    if letras and all(ch.isupper() for ch in letras):
        return texto.capitalize()
    return valor


def sanitizar_nome_arquivo(nome):
    invalidos = '\\/:*?"<>|'
    nome_str = to_str(nome)
    for ch in invalidos:
        nome_str = nome_str.replace(ch, "_")
    return nome_str.strip()


def gerar_nome_unico(base_nome, pasta):
    base = sanitizar_nome_arquivo(base_nome) or "arquivo"
    nome_atual = base
    sufixo = 0
    while (os.path.exists(os.path.join(pasta, f"{nome_atual}.xlsx"))
           or os.path.exists(os.path.join(pasta, f"{nome_atual}.pdf"))):
        sufixo += 1
        nome_atual = f"{base} {sufixo}"
    return nome_atual


def formatar_data_brasil(valor):
    if not valor:
        return ""
    if isinstance(valor, datetime):
        return valor.strftime("%d/%m/%Y")
    texto = to_str(valor).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(texto, fmt).strftime("%d/%m/%Y")
        except ValueError:
            continue
    return texto


def formatar_km(valor):
    """Converte um km em formato decimal (2.37, '2,37', 0.162 etc.) para o
    padrão KKK+MMM (ex.: 002+370)."""
    if valor is None:
        return ''
    if isinstance(valor, (int, float)):
        total_m = round(float(valor) * 1000)
    else:
        texto = str(valor).strip()
        if not texto:
            return ''
        # já vem como "123+456"?
        m = re.fullmatch(r'(\d+)\s*\+\s*(\d{1,3})', texto)
        if m:
            km, metros = int(m.group(1)), int(m.group(2))
            return f'{km:03d}+{metros:03d}'
        try:
            total_m = round(float(texto.replace(',', '.')) * 1000)
        except ValueError:
            return ''
    km, metros = divmod(int(total_m), 1000)
    return f'{km:03d}+{metros:03d}'


def build_photo_index(fotos_dir):
    """Varre a pasta de fotos E TODAS AS SUBPASTAS, e devolve um dicionário
    {nome_do_arquivo: caminho_completo}."""
    indice = {}
    if not fotos_dir or not os.path.isdir(fotos_dir):
        return indice
    for raiz, _dirs, arquivos in os.walk(fotos_dir):
        for nome_arquivo in arquivos:
            if nome_arquivo not in indice:
                indice[nome_arquivo] = os.path.join(raiz, nome_arquivo)
    return indice


def construir_indice_colunas(ws_dados):
    """Lê a primeira linha da planilha de dados e devolve {nome_cabecalho: indice_coluna (1-based)}."""
    indice = {}
    for c in range(1, ws_dados.max_column + 1):
        v = ws_dados.cell(row=1, column=c).value
        if v:
            indice[str(v).strip()] = c
    return indice


def get_campo(row_dict_vals, idx_colunas, chave_campo):
    """row_dict_vals: lista de valores da linha (1-based via idx_colunas)."""
    nome_cabecalho = CAMPOS.get(chave_campo)
    col = idx_colunas.get(nome_cabecalho)
    if not col or col > len(row_dict_vals):
        return None
    return row_dict_vals[col - 1]


def marcar_diagnostico(ws_modelo, texto_diagnostico):
    texto = to_str(texto_diagnostico).upper()
    if "SEM DANOS NO ELEMENTO" in texto or texto.strip().rstrip('|') == 'OK':
        escrever_celula(ws_modelo, 'D14', "X")
    if "REPARAR" in texto:
        escrever_celula(ws_modelo, 'D15', "X")
    if "LIMPAR" in texto or "LIMPEZA" in texto:
        escrever_celula(ws_modelo, 'D16', "X")
    if "IMPLANTAR" in texto:
        escrever_celula(ws_modelo, 'D17', "X")


def processar_linha(ws_modelo, row_vals, idx_colunas, indice_fotos, avisos, identificador_log):
    def campo(chave):
        return get_campo(row_vals, idx_colunas, chave)

    valor_rodovia = campo('rodovia')
    valor_tipo = campo('tipo_drenagem')
    valor_data = campo('data')

    # A5 - "Drenagem Superficial Rod. <rodovia> <tipo>"
    tipo_cap = capitalizar_se_todo_maiusculo(valor_tipo)
    escrever_celula(ws_modelo, 'A5', f"Drenagem Superficial Rod. {to_str(valor_rodovia)} {to_str(tipo_cap)}".strip())

    # H4 - data
    escrever_celula(ws_modelo, 'H4', formatar_data_brasil(valor_data))

    # Mapeamentos diretos (com capitalização quando aplicável)
    CAMPOS_EXTENSAO_ZERO_EM_BRANCO = {'limpeza_ext', 'reparar_ext', 'implantar_ext'}
    for chave_campo, celula in MAPEAMENTO_SIMPLES.items():
        valor = campo(chave_campo)
        if chave_campo in CAMPOS_EXTENSAO_ZERO_EM_BRANCO and (valor == 0 or valor is None):
            valor = None  # não mostra "0" quando o diagnóstico não se aplica (ex.: elemento Bom)
        elif chave_campo not in CAMPOS_SEM_CAPITALIZACAO:
            valor = capitalizar_se_todo_maiusculo(valor)
        escrever_celula(ws_modelo, celula, valor)

    # KM inicial / final
    escrever_celula(ws_modelo, 'G6', formatar_km(campo('km_inicial')))
    escrever_celula(ws_modelo, 'G7', formatar_km(campo('km_final')))

    # Diagnóstico (marca X em D14-D17)
    marcar_diagnostico(ws_modelo, campo('diagnostico'))

    # Fotos
    imagens = {}
    foto1 = campo('foto1')
    foto2 = campo('foto2')
    if indice_fotos and foto1:
        p1 = indice_fotos.get(str(foto1))
        if p1:
            imagens['A20'] = p1
        else:
            avisos.append(f"{identificador_log}: foto '{foto1}' não encontrada na pasta de fotos (nem em subpastas).")
    if indice_fotos and foto2:
        p2 = indice_fotos.get(str(foto2))
        if p2:
            imagens['E20'] = p2
        else:
            avisos.append(f"{identificador_log}: foto '{foto2}' não encontrada na pasta de fotos (nem em subpastas).")

    nome_base_arquivo = to_str(campo('identificacao')).strip()
    return imagens, nome_base_arquivo


# ----------------------------------------------------------------------
# Interface gráfica
# ----------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gerador de Fichas de Drenagem (DS)")
        self.geometry("760x600")

        self.var_modelo = tk.StringVar()
        self.var_dados = tk.StringVar()
        self.var_fotos = tk.StringVar()
        self.var_saida = tk.StringVar()

        pad = {'padx': 10, 'pady': 6}
        ttk.Label(self, text="Gerador de Fichas de Drenagem (DS)",
                  font=("Segoe UI", 14, "bold")).pack(**pad)

        if not WIN32COM_OK:
            ttk.Label(
                self, foreground="red", wraplength=720, justify='left',
                text="Atenção: o pacote 'pywin32' não foi encontrado. Este script "
                     "precisa do Microsoft Excel (via pywin32) para inserir as fotos "
                     "e gerar o PDF. Instale com:  pip install pywin32"
            ).pack(padx=10, pady=4)

        self._linha_arquivo("1) Planilha-modelo da ficha (modelo_ds.xlsx):", self.var_modelo)
        self._linha_arquivo("2) Planilha de DADOS tabulados da monitoração:", self.var_dados)
        self._linha_pasta("3) Pasta com as FOTOS:", self.var_fotos)
        self._linha_pasta("4) Pasta de saída (onde salvar os arquivos gerados):", self.var_saida)

        ttk.Button(self, text="Gerar fichas", command=self.gerar).pack(pady=10)

        self.log_box = scrolledtext.ScrolledText(self, height=18)
        self.log_box.pack(fill='both', expand=True, padx=10, pady=10)

    def _linha_arquivo(self, label, var):
        frame = ttk.Frame(self)
        frame.pack(fill='x', padx=10, pady=4)
        ttk.Label(frame, text=label, wraplength=720, justify='left').pack(anchor='w')
        sub = ttk.Frame(frame)
        sub.pack(fill='x')
        ttk.Entry(sub, textvariable=var).pack(side='left', fill='x', expand=True)
        ttk.Button(sub, text="Selecionar...",
                   command=lambda: self._escolher(var)).pack(side='left', padx=4)

    def _linha_pasta(self, label, var):
        frame = ttk.Frame(self)
        frame.pack(fill='x', padx=10, pady=4)
        ttk.Label(frame, text=label, wraplength=720, justify='left').pack(anchor='w')
        sub = ttk.Frame(frame)
        sub.pack(fill='x')
        ttk.Entry(sub, textvariable=var).pack(side='left', fill='x', expand=True)
        ttk.Button(sub, text="Selecionar pasta...",
                   command=lambda: self._escolher_pasta(var)).pack(side='left', padx=4)

    def _escolher(self, var):
        path = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xlsm *.xls")])
        if path:
            var.set(path)

    def _escolher_pasta(self, var):
        path = filedialog.askdirectory()
        if path:
            var.set(path)

    def log(self, msg):
        self.log_box.insert('end', msg + "\n")
        self.log_box.see('end')
        self.update_idletasks()

    def gerar(self):
        if not WIN32COM_OK:
            messagebox.showerror(
                "Erro",
                "O pacote 'pywin32' não está instalado/disponível para este Python.\n\n"
                "Rode no terminal:  pip install pywin32\n"
                "e confirme que está usando o MESMO Python para instalar e para rodar este script."
            )
            return
        modelo = self.var_modelo.get().strip()
        dados = self.var_dados.get().strip()
        fotos = self.var_fotos.get().strip()
        saida = self.var_saida.get().strip()

        if not modelo or not os.path.exists(modelo):
            messagebox.showerror("Erro", "Selecione a planilha-modelo da ficha.")
            return
        if not dados or not os.path.exists(dados):
            messagebox.showerror("Erro", "Selecione a planilha de dados tabulados.")
            return
        if not saida:
            messagebox.showerror("Erro", "Selecione a pasta de saída.")
            return

        os.makedirs(saida, exist_ok=True)
        self.log_box.delete('1.0', 'end')
        threading.Thread(target=self._executar, args=(modelo, dados, fotos, saida), daemon=True).start()

    def _executar(self, modelo, dados, fotos, saida):
        excel = None
        try:
            self.log("Lendo planilha de dados...")
            wb_dados = load_workbook(dados, data_only=True)
            ws_dados = wb_dados.active
            idx_colunas = construir_indice_colunas(ws_dados)

            # valida que os cabeçalhos essenciais existem
            faltando = [nome for chave, nome in CAMPOS.items() if nome not in idx_colunas]
            if faltando:
                self.log("Atenção: não encontrei estas colunas na planilha de dados "
                         f"(serão ignoradas): {', '.join(faltando)}")

            avisos = []
            indice_fotos = build_photo_index(fotos)
            if fotos and not indice_fotos:
                self.log("Atenção: não encontrei nenhuma foto na pasta selecionada (nem em subpastas).")
            excel = win32com.client.Dispatch("Excel.Application")
            excel.Visible = False

            total = 0
            for r in range(2, ws_dados.max_row + 1):
                row_vals = [ws_dados.cell(row=r, column=c).value
                            for c in range(1, ws_dados.max_column + 1)]
                if not any(row_vals):
                    continue
                # ignora linhas sem identificação (provavelmente vazias/lixo)
                ident_col = idx_colunas.get(CAMPOS['identificacao'])
                if not ident_col or not row_vals[ident_col - 1]:
                    continue

                wb_modelo = load_workbook(modelo)
                ws_modelo = wb_modelo.active

                imagens, nome_base = processar_linha(
                    ws_modelo, row_vals, idx_colunas, indice_fotos, avisos, f"linha {r}"
                )

                nome_unico = gerar_nome_unico(nome_base, saida)
                caminho_xlsx = os.path.join(saida, f"{nome_unico}.xlsx")
                caminho_pdf = os.path.join(saida, f"{nome_unico}.pdf")
                wb_modelo.save(caminho_xlsx)

                wb = excel.Workbooks.Open(os.path.abspath(caminho_xlsx))
                ws = wb.ActiveSheet
                for celula, caminho_imagem in imagens.items():
                    img = ws.Shapes.AddPicture(
                        Filename=os.path.abspath(caminho_imagem),
                        LinkToFile=False, SaveWithDocument=True,
                        Left=ws.Range(celula).Left + 10,
                        Top=ws.Range(celula).Top,
                        Width=-1, Height=-1
                    )
                    img.LockAspectRatio = False
                    img.Width = 230
                    img.Height = 120

                ws.PageSetup.PrintArea = "A1:H30"
                wb.Save()
                wb.ExportAsFixedFormat(0, os.path.abspath(caminho_pdf))
                wb.Close(SaveChanges=False)

                total += 1
                self.log(f"  {nome_unico} -> gerado (xlsx + pdf)")

            self.log(f"\nConcluído! {total} fichas geradas em: {saida}")
            for a in avisos:
                self.log("  [aviso] " + a)
            messagebox.showinfo("Concluído", f"{total} fichas geradas com sucesso.")
        except Exception:
            self.log("\nERRO:\n" + traceback.format_exc())
            messagebox.showerror("Erro", "Ocorreu um erro durante o processamento. Veja o log.")
        finally:
            if excel is not None:
                try:
                    excel.Quit()
                except Exception:
                    pass


if __name__ == '__main__':
    app = App()
    app.mainloop()
