# Gerador de Fichas de Drenagem (DS)

Gera, a partir da planilha de dados tabulados da monitoração de drenagem,
1 arquivo `.xlsx` + 1 arquivo `.pdf` para CADA elemento (sarjeta, meio-fio,
descida d'água, valeta etc.), no mesmo padrão da ficha oficial ANTT.

## 1. Instalação

1. Instale o Python 3: https://www.python.org/downloads/
   (Marque "Add Python to PATH" no instalador, no Windows)
2. Abra o terminal na pasta do script e instale as dependências:
   ```
   pip install openpyxl pywin32
   ```
   **Importante:** este script precisa do **Microsoft Excel instalado**
   no computador, porque usa o Excel (via `pywin32`) para inserir as fotos
   e gerar o PDF — exatamente como o script original que você já tinha.

## 2. Como usar

1. Execute: `python gerador_fichas_drenagem.py`
2. Selecione:
   - A planilha-**modelo** da ficha (`modelo_ds.xlsx`);
   - A planilha de **dados tabulados** da monitoração;
   - A pasta com as **fotos**;
   - A pasta de **saída**.
3. Clique em **"Gerar fichas"**.

Os arquivos são salvos com o nome da **Identificação** de cada elemento
(ex.: `SJ 040 MG 001+620 N 1.xlsx` e `.pdf`).

## 3. O que foi ajustado em relação ao script original

- **Colunas lidas pelo nome do cabeçalho**, não mais por letra fixa. Isso
  evita erro se a ordem das colunas mudar entre exportações — e corrigiu
  um problema real: a coluna de **Sentido** estava sendo lida da coluna
  errada (a coluna D é "Faixa", não "Sentido"; o Sentido está em outra
  coluna, identificada agora pelo nome).
- **KM inicial/final**: convertido para o formato `KKK+MMM` (ex.:
  `002+370`), aceitando o valor tanto como número decimal (`2.37`) quanto
  como texto com vírgula (`"2,37"`).
- **Capitalização**: qualquer campo que vier 100% em maiúsculas da
  planilha (Tipo, Material, Ambiente, Estado de Conservação etc.) é
  convertido para "Primeira letra maiúscula, resto minúsculo" (ex.:
  `"RURAL"` → `"Rural"`). A **Identificação** e a **sigla da rodovia**
  (ex.: `BR-040-MG`) NÃO são alteradas.
- Se a planilha de dados não tiver alguma das colunas esperadas, o script
  avisa no log quais estão faltando, mas continua processando as demais.

## 4. Pontos para você revisar

- O **Diagnóstico** (OK / Reparar / Limpeza / Implantar) é identificado
  procurando essas palavras no texto da coluna "Diagnostico" (ex.: "SEM
  DANOS NO ELEMENTO" → OK, "LIMPAR" → Limpeza). Se em algum arquivo essas
  palavras vierem diferentes, me avise para eu ajustar.
- O campo **"Tipo:"** da ficha (linha 11) continua sem um mapeamento de
  coluna definido, igual ao script original — se houver uma coluna pra
  esse campo, me diga qual.
- O tamanho da foto na ficha está fixo em 230x120 (igual ao script
  original). Se quiser ajustar a proporção/tamanho, é só falar, como
  fizemos para as fichas EPS.

## 5. Arquivos deste pacote
- `gerador_fichas_drenagem.py` — script com interface gráfica
- `requirements.txt`
